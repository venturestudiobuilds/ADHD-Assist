ADHD Assist — mini-starter-pack

This is a placeholder file. Replace the contents of this pack with the real
worksheets, scripts and trackers, then re-zip as mini-starter-pack.zip in content/packs/.
