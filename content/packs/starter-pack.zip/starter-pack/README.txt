ADHD Assist — starter-pack

Placeholder file. Replace with the real pack contents and re-zip as starter-pack.zip in content/packs/.
