ADHD Assist — bundle

Placeholder file. Replace with the real pack contents and re-zip as bundle.zip in content/packs/.
