ADHD Assist — admin-system

Placeholder file. Replace with the real pack contents and re-zip as admin-system.zip in content/packs/.
