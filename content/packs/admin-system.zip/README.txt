ADHD Admin System - what's in this download
============================================

1. ADHD-Admin-System.html
   The interactive tracker. Open it in any browser (double-click it).
   Everything you type saves automatically in that browser via localStorage.
   No account, no internet needed after opening.
   NOTE: data lives in the browser profile on that device. Use the Export
   button (top right) to back up, and Import to restore or move devices.

2. ADHD-Admin-System.xlsx
   The same system as a spreadsheet, for Excel / Google Sheets / LibreOffice.
   To use in Google Sheets: drive.google.com → New → File upload → open with
   Google Sheets.

3. Notion-Build-Guide.pdf
   Step-by-step instructions to rebuild the system as a Notion workspace.

Educational only - not medical advice. Full disclaimer on the website.
