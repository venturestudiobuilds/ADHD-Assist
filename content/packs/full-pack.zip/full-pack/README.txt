ADHD Assist — full-pack

Placeholder file. Replace with the real pack contents and re-zip as full-pack.zip in content/packs/.
